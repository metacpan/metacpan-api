package CPAN::Test::Dummy::Perl5::VersionBump::Decrease;
our $VERSION = "0.02";
1;

