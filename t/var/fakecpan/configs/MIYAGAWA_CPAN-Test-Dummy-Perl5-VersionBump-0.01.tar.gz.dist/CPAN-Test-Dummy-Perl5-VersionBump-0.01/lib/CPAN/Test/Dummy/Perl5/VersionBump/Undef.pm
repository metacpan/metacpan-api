package CPAN::Test::Dummy::Perl5::VersionBump::Undef;
1;

