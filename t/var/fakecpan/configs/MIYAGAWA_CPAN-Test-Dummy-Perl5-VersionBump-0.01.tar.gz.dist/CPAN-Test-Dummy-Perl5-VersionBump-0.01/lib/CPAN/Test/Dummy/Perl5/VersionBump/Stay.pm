package CPAN::Test::Dummy::Perl5::VersionBump::Stay;
our $VERSION = "0.01";
1;

