package CPAN::Test::Dummy::Perl5::VersionBump::Decrease;
our $VERSION = "0.01";
1;

